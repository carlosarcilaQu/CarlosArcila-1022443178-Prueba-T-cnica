﻿using Microsoft.AspNetCore.Mvc;
using OutletRentalCars.Application.Reservations.Create;
using OutletRentalCars.Infrastructure.Reservations;

namespace OutletRentalCars.Api.Controllers
{
    [ApiController]
    [Route("api/reservations")]
    public sealed class ReservationsController : ControllerBase
    {
        private readonly ICreateReservationUseCase _useCase;

        public ReservationsController(ICreateReservationUseCase useCase) => _useCase = useCase;

        [HttpPost]
        public async Task<ActionResult<CreateReservationResult>> Create([FromBody] CreateReservationCommand command, CancellationToken ct)
            => Ok(await _useCase.ExecuteAsync(command, ct));
    }
}
