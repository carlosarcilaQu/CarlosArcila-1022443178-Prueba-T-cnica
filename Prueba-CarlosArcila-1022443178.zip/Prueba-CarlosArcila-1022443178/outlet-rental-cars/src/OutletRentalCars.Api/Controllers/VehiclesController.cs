﻿using Microsoft.AspNetCore.Mvc;
using OutletRentalCars.Application.Vehicles.Search;
using OutletRentalCars.Domain.Vehicles.Search;

namespace OutletRentalCars.Api.Controllers
{
    [ApiController]
    [Route("api/vehicles")]
    public sealed class VehiclesController : ControllerBase
    {
        private readonly ISearchVehiclesUseCase _useCase;

        public VehiclesController(ISearchVehiclesUseCase useCase) => _useCase = useCase;

        [HttpGet("search")]
        public async Task<ActionResult<IReadOnlyList<VehicleSearchResult>>> Search([FromQuery] string pickupLocationId,
            [FromQuery] string dropoffLocationId,
            [FromQuery] DateTime pickupAt,
            [FromQuery] DateTime dropoffAt,CancellationToken ct)
        {
            var result = await _useCase.ExecuteAsync(
                new SearchVehiclesQuery(pickupLocationId, dropoffLocationId, pickupAt, dropoffAt),
                ct);

            return Ok(result);
        }
    }
}
