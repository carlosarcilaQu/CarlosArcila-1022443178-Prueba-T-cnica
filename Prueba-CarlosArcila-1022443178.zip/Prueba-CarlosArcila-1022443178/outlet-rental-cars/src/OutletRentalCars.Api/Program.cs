using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using OutletRentalCars.Application.Common.Events;
using OutletRentalCars.Domain.Reservations;
using OutletRentalCars.Infrastructure.Catalog;
using OutletRentalCars.Infrastructure.Persistence;
using OutletRentalCars.Infrastructure.Reservations;
using OutletRentalCars.Infrastructure;
using OutletRentalCars.Application;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<AppDbContext>(options =>
{
    var cs = builder.Configuration.GetConnectionString("MySql")
             ?? throw new InvalidOperationException("Missing ConnectionStrings:MySql");
    options.UseMySql(cs, Microsoft.EntityFrameworkCore.ServerVersion.AutoDetect(cs));
});

builder.Services.Configure<MongoSettings>(builder.Configuration.GetSection("Mongo"));
builder.Services.AddSingleton<IMongoClient>(sp =>
{
    var settings = sp.GetRequiredService<IOptions<MongoSettings>>().Value;
    return new MongoClient(settings.ConnectionString);
});

builder.Services.AddScoped(sp =>
{
    var settings = sp.GetRequiredService<IOptions<MongoSettings>>().Value;
    var client = sp.GetRequiredService<IMongoClient>();
    return client.GetDatabase(settings.Database);
});

builder.Services.AddApplication();
builder.Services.AddInfrastructure();
builder.Services.AddScoped<IDomainEventHandler<VehicleReservedEvent>, VehicleReservedEventHandler>();


var app = builder.Build();

app.UseExceptionHandler(exceptionApp =>
{
    exceptionApp.Run(async context =>
    {
        var feature = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerFeature>();
        var ex = feature?.Error;

        var (status, title) = ex switch
        {
            OutletRentalCars.Application.Common.Exceptions.BadRequestException => (StatusCodes.Status400BadRequest, "Bad Request"),
            OutletRentalCars.Application.Common.Exceptions.NotFoundException => (StatusCodes.Status404NotFound, "Not Found"),
            _ => (StatusCodes.Status500InternalServerError, "Internal Server Error")
        };

        context.Response.StatusCode = status;
        context.Response.ContentType = "application/problem+json";

        var problem = new Microsoft.AspNetCore.Mvc.ProblemDetails
        {
            Status = status,
            Title = title,
            Detail = ex?.Message,
            Instance = $"{context.Request.Method} {context.Request.Path}"
        };

        await context.Response.WriteAsJsonAsync(problem);
    });
});


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseAuthorization();

app.MapControllers();

app.Run();
