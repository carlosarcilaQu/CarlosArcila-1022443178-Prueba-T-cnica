﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Time
{
    public static class DateRange
    {
        public static bool Overlaps(DateTime start1, DateTime end1, DateTime start2, DateTime end2)
            => start1 < end2 && end1 > start2;
    }
}
