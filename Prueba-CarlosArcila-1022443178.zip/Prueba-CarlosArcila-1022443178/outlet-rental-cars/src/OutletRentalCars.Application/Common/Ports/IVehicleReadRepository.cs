﻿using OutletRentalCars.Domain.Vehicles;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Ports
{
    public interface IVehicleReadRepository
    {
        IQueryable<Vehicle> Query();
    }
}
