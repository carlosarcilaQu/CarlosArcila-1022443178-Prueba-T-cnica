﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Ports
{
    public sealed record LocationInfo(string LocationId, string CountryCode);
    public sealed record MarketInfo(string CountryCode, IReadOnlyList<string> EnabledVehicleTypeCodes);

    public interface ICatalogRepository
    {
        Task<LocationInfo?> GetLocationAsync(string locationId, CancellationToken ct);
        Task<MarketInfo?> GetMarketByCountryAsync(string countryCode, CancellationToken ct);
    }
}
