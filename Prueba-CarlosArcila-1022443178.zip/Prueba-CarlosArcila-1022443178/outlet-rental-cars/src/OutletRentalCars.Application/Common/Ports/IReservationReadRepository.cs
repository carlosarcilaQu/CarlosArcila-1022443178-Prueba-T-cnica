﻿using OutletRentalCars.Domain.Reservations;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Ports
{
    public interface IReservationReadRepository
    {
        IQueryable<Reservation> Query();
        Task AddAsync(Reservation reservation, CancellationToken ct);
        Task SaveChangesAsync(CancellationToken ct);
    }
}
