﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Events
{
    public interface IDomainEventDispatcher
    {
        Task PublishAsync<TEvent>(TEvent domainEvent, CancellationToken ct);
    }
}
