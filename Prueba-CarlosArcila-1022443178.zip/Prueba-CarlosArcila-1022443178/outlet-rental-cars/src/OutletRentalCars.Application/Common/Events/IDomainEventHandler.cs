﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Common.Events
{
    public interface IDomainEventHandler<in TEvent>
    {
        Task HandleAsync(TEvent domainEvent, CancellationToken ct);
    }
}
