﻿using Microsoft.EntityFrameworkCore;
using OutletRentalCars.Application.Common.Events;
using OutletRentalCars.Application.Common.Exceptions;
using OutletRentalCars.Application.Common.Ports;
using OutletRentalCars.Domain.Reservations;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Reservations.Create
{
    public sealed class CreateReservationUseCase : ICreateReservationUseCase
    {
        private readonly IVehicleReadRepository _vehicles;
        private readonly IReservationReadRepository _reservations;
        private readonly IDomainEventDispatcher _events;

        public CreateReservationUseCase(
            IVehicleReadRepository vehicles,
            IReservationReadRepository reservations,
            IDomainEventDispatcher events)
        {
            _vehicles = vehicles;
            _reservations = reservations;
            _events = events;
        }

        public async Task<CreateReservationResult> ExecuteAsync(CreateReservationCommand command, CancellationToken ct)
        {
            if (command.PickupAt >= command.DropoffAt)
                throw new BadRequestException("Invalid date range. PickupAt must be before DropoffAt.");

            var vehicleExists = await _vehicles.Query().AsNoTracking()
                .AnyAsync(v => v.Id == command.VehicleId, ct);

            if (!vehicleExists)
                throw new NotFoundException("Vehicle not found.");

            var hasOverlap = await _reservations.Query().AsNoTracking()
                .Where(r => r.VehicleId == command.VehicleId)
                .Where(r => r.Status == ReservationStatus.Active)
                .AnyAsync(r => r.PickupAt < command.DropoffAt && r.DropoffAt > command.PickupAt, ct);

            if (hasOverlap)
                throw new BadRequestException("Vehicle is not available for the requested range.");

            var reservation = new Reservation
            {
                Id = Guid.NewGuid(),
                VehicleId = command.VehicleId,
                PickupLocationId = command.PickupLocationId,
                DropoffLocationId = command.DropoffLocationId,
                PickupAt = command.PickupAt,
                DropoffAt = command.DropoffAt,
                Status = ReservationStatus.Active
            };

            await _reservations.AddAsync(reservation, ct);
            await _reservations.SaveChangesAsync(ct);

            await _events.PublishAsync(
                new VehicleReservedEvent(reservation.Id, reservation.VehicleId, reservation.PickupAt, reservation.DropoffAt),
                ct);

            return new CreateReservationResult(reservation.Id);
        }
    }
}
