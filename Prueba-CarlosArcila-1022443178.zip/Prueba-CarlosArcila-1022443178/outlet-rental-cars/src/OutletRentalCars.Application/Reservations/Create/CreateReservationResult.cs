﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Reservations.Create
{
    public sealed record CreateReservationResult(Guid ReservationId);
}
