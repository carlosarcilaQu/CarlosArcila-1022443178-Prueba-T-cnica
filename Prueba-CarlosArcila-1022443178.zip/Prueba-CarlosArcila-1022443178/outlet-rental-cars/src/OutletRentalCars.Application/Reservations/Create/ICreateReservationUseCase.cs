﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Reservations.Create
{
    public interface ICreateReservationUseCase
    {
        Task<CreateReservationResult> ExecuteAsync(CreateReservationCommand command, CancellationToken ct);
    }
}
