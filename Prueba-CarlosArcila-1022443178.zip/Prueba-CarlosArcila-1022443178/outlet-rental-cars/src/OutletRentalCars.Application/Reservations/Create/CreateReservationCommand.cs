﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Reservations.Create
{
    public sealed record CreateReservationCommand(
    Guid VehicleId,
    string PickupLocationId,
    string DropoffLocationId,
    DateTime PickupAt,
    DateTime DropoffAt);
}
