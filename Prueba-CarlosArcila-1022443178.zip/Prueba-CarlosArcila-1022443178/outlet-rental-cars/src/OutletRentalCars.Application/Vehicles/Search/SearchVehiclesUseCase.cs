﻿using Microsoft.EntityFrameworkCore;
using OutletRentalCars.Application.Common.Ports;
using OutletRentalCars.Domain.Reservations;
using OutletRentalCars.Domain.Vehicles;
using OutletRentalCars.Domain.Vehicles.Search;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Vehicles.Search
{
    public sealed class SearchVehiclesUseCase : ISearchVehiclesUseCase
    {
        private readonly IVehicleReadRepository _vehicles;
        private readonly IReservationReadRepository _reservations;
        private readonly ICatalogRepository _catalog;

        public SearchVehiclesUseCase(
            IVehicleReadRepository vehicles,
            IReservationReadRepository reservations,
            ICatalogRepository catalog)
        {
            _vehicles = vehicles;
            _reservations = reservations;
            _catalog = catalog;
        }

        public async Task<IReadOnlyList<VehicleSearchResult>> ExecuteAsync(SearchVehiclesQuery query, CancellationToken ct)
        {
            if (query.PickupAt >= query.DropoffAt)
                return Array.Empty<VehicleSearchResult>();

            var location = await _catalog.GetLocationAsync(query.PickupLocationId, ct);
            if (location is null)
                return Array.Empty<VehicleSearchResult>();

            var market = await _catalog.GetMarketByCountryAsync(location.CountryCode, ct);
            if (market is null || market.EnabledVehicleTypeCodes.Count == 0)
                return Array.Empty<VehicleSearchResult>();

            var enabledTypes = market.EnabledVehicleTypeCodes;

            var result = await _vehicles.Query()
                .AsNoTracking()
                .Where(v => v.Status == VehicleStatus.Available)
                .Where(v => v.PickupLocationId == query.PickupLocationId)
                .Where(v => enabledTypes.Contains(v.VehicleTypeCode))
                .Where(v => !_reservations.Query().AsNoTracking().Any(r =>
                    r.VehicleId == v.Id &&
                    r.Status == ReservationStatus.Active &&
                    r.PickupAt < query.DropoffAt &&
                    r.DropoffAt > query.PickupAt))
                .Select(v => new VehicleSearchResult(v.Id, v.Plate, v.VehicleTypeCode, v.PickupLocationId))
                .ToListAsync(ct);

            return result;
        }
    }
}
