﻿using OutletRentalCars.Domain.Vehicles.Search;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application.Vehicles.Search
{
    public interface ISearchVehiclesUseCase
    {
        Task<IReadOnlyList<VehicleSearchResult>> ExecuteAsync(SearchVehiclesQuery query, CancellationToken ct);
    }
}
