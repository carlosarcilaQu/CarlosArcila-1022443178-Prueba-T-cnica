﻿using Microsoft.Extensions.DependencyInjection;
using OutletRentalCars.Application.Reservations.Create;
using OutletRentalCars.Application.Vehicles.Search;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddScoped<ISearchVehiclesUseCase, SearchVehiclesUseCase>();
            services.AddScoped<ICreateReservationUseCase, CreateReservationUseCase>();
            return services;
        }
    }
}
