﻿using OutletRentalCars.Application.Common.Ports;
using OutletRentalCars.Domain.Vehicles;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Persistence
{

    public sealed class EfVehicleReadRepository : IVehicleReadRepository
    {
        private readonly AppDbContext _db;

        public EfVehicleReadRepository(AppDbContext db) => _db = db;

        public IQueryable<Vehicle> Query() => _db.Vehicles;
    }
}
