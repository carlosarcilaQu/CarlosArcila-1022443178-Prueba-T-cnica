﻿using OutletRentalCars.Application.Common.Ports;
using OutletRentalCars.Domain.Reservations;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Persistence
{
    public sealed class EfReservationRepository : IReservationReadRepository
    {
        private readonly AppDbContext _db;

        public EfReservationRepository(AppDbContext db) => _db = db;

        public IQueryable<Reservation> Query() => _db.Reservations;

        public Task AddAsync(Reservation reservation, CancellationToken ct)
        {
            _db.Reservations.Add(reservation);
            return Task.CompletedTask;
        }

        public Task SaveChangesAsync(CancellationToken ct) => _db.SaveChangesAsync(ct);
    }
}
