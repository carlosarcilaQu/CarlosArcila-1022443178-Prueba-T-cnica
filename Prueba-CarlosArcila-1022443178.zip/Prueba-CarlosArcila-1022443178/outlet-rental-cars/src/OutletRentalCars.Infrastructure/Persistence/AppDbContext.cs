﻿using Microsoft.EntityFrameworkCore;
using OutletRentalCars.Domain.Reservations;
using OutletRentalCars.Domain.Vehicles;

namespace OutletRentalCars.Infrastructure.Persistence;

public sealed class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    public DbSet<Reservation> Reservations => Set<Reservation>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Vehicle>(e =>
        {
            e.ToTable("vehicles");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Plate).HasColumnName("plate");
            e.Property(x => x.Status).HasConversion<string>().HasColumnName("status");
            e.Property(x => x.PickupLocationId).HasColumnName("pickup_location_id");
            e.Property(x => x.VehicleTypeCode).HasColumnName("vehicle_type_code");
        });

        modelBuilder.Entity<Reservation>(e =>
        {
            e.ToTable("reservations");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.VehicleId).HasColumnName("vehicle_id");
            e.Property(x => x.PickupLocationId).HasColumnName("pickup_location_id");
            e.Property(x => x.DropoffLocationId).HasColumnName("dropoff_location_id");
            e.Property(x => x.PickupAt).HasColumnName("pickup_at");
            e.Property(x => x.DropoffAt).HasColumnName("dropoff_at");
            e.Property(x => x.Status).HasConversion<string>().HasColumnName("status");
        });
    }
}

