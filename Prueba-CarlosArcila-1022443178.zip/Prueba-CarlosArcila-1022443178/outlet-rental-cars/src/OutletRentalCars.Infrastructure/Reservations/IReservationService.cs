﻿using OutletRentalCars.Application.Reservations.Create;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Reservations
{
    public interface IReservationService
    {
        Task<CreateReservationResult> CreateAsync(CreateReservationCommand command, CancellationToken ct);
    }
}
