﻿using Microsoft.Extensions.Logging;
using OutletRentalCars.Application.Common.Events;
using OutletRentalCars.Domain.Reservations;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Reservations
{
    public sealed class VehicleReservedEventHandler : IDomainEventHandler<VehicleReservedEvent>
    {
        private readonly ILogger<VehicleReservedEventHandler> _logger;

        public VehicleReservedEventHandler(ILogger<VehicleReservedEventHandler> logger)
        {
            _logger = logger;
        }

        public Task HandleAsync(VehicleReservedEvent domainEvent, CancellationToken ct)
        {
            _logger.LogInformation(
                "VehicleReservedEvent handled. ReservationId={ReservationId}, VehicleId={VehicleId}, PickupAt={PickupAt}, DropoffAt={DropoffAt}",
                domainEvent.ReservationId,
                domainEvent.VehicleId,
                domainEvent.PickupAt,
                domainEvent.DropoffAt);

            return Task.CompletedTask;
        }
    }
}
