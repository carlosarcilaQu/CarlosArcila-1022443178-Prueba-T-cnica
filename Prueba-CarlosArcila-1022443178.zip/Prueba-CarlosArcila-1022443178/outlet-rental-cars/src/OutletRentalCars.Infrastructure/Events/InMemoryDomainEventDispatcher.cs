﻿using Microsoft.Extensions.DependencyInjection;
using OutletRentalCars.Application.Common.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Events
{
    public sealed class InMemoryDomainEventDispatcher : IDomainEventDispatcher
    {
        private readonly IServiceProvider _serviceProvider;

        public InMemoryDomainEventDispatcher(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public async Task PublishAsync<TEvent>(TEvent domainEvent, CancellationToken ct)
        {
            using var scope = _serviceProvider.CreateScope();
            var handlers = scope.ServiceProvider.GetServices<IDomainEventHandler<TEvent>>();

            foreach (var handler in handlers)
                await handler.HandleAsync(domainEvent, ct);
        }
    }
}
