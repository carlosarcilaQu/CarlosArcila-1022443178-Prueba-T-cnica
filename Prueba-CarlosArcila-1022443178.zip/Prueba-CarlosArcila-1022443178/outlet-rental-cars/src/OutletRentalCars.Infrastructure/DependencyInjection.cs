﻿using Microsoft.Extensions.DependencyInjection;
using OutletRentalCars.Application.Common.Events;
using OutletRentalCars.Application.Common.Ports;
using OutletRentalCars.Infrastructure.Catalog;
using OutletRentalCars.Infrastructure.Events;
using OutletRentalCars.Infrastructure.Persistence;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IVehicleReadRepository, EfVehicleReadRepository>();
            services.AddScoped<IReservationReadRepository, EfReservationRepository>();
            services.AddScoped<ICatalogRepository, MongoCatalogRepository>();

            services.AddSingleton<IDomainEventDispatcher, InMemoryDomainEventDispatcher>();

            return services;
        }
    }
}
