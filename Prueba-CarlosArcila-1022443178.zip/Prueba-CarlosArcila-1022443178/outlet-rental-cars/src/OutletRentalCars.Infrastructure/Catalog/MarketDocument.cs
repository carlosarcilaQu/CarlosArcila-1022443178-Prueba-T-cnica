﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Catalog
{

    [BsonIgnoreExtraElements]
    public sealed class MarketDocument
    {
        [BsonId]
        [BsonElement("_id")]
        public string CountryCode { get; set; } = string.Empty;

        [BsonElement("enabledVehicleTypeCodes")]
        public List<string> EnabledVehicleTypeCodes { get; set; } = new();
    }
}
