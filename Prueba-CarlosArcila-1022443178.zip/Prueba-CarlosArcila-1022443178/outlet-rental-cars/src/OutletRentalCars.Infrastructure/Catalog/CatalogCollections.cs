﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Catalog
{
    public static class CatalogCollections
    {
        public const string Locations = "locations";
        public const string Markets = "markets";
    }
}
