﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Catalog
{

    [BsonIgnoreExtraElements]
    public sealed class LocationDocument
    {
        [BsonId]
        [BsonElement("_id")]
        public string Id { get; set; } = string.Empty;

        [BsonElement("countryCode")]
        public string CountryCode { get; set; } = string.Empty;
    }
}
