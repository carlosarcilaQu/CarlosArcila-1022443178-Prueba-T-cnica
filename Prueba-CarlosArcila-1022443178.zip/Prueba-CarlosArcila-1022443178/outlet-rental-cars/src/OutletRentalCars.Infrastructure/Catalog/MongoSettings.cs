﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Catalog
{
    public sealed class MongoSettings
    {
        public string ConnectionString { get; init; } = string.Empty;
        public string Database { get; init; } = string.Empty;
    }
}
