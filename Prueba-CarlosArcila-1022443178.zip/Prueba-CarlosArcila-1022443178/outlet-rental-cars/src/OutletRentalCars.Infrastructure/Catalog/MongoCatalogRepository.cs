﻿using MongoDB.Driver;
using OutletRentalCars.Application.Common.Ports;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Infrastructure.Catalog
{
    public sealed class MongoCatalogRepository : ICatalogRepository
    {
        private readonly IMongoDatabase _db;

        public MongoCatalogRepository(IMongoDatabase db) => _db = db;

        public async Task<LocationInfo?> GetLocationAsync(string locationId, CancellationToken ct)
        {
            var col = _db.GetCollection<LocationDocument>(CatalogCollections.Locations);
            var doc = await col.Find(x => x.Id == locationId).FirstOrDefaultAsync(ct);
            return doc is null ? null : new LocationInfo(doc.Id, doc.CountryCode);
        }

        public async Task<MarketInfo?> GetMarketByCountryAsync(string countryCode, CancellationToken ct)
        {
            var col = _db.GetCollection<MarketDocument>(CatalogCollections.Markets);
            var doc = await col.Find(x => x.CountryCode == countryCode).FirstOrDefaultAsync(ct);
            return doc is null ? null : new MarketInfo(doc.CountryCode, doc.EnabledVehicleTypeCodes);
        }
    }
}
