﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Vehicles
{
    public enum VehicleStatus
    {
        Available = 1,
        Maintenance = 2,
        Unavailable = 3
    }
}
