﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Vehicles
{
    public sealed class Vehicle
    {
        public Guid Id { get; init; }
        public string Plate { get; init; } = string.Empty;
        public VehicleStatus Status { get; set; }
        public string PickupLocationId { get; set; } = string.Empty;
        public string VehicleTypeCode { get; set; } = string.Empty;
    }
}
