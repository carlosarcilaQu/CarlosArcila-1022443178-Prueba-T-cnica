﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Vehicles.Search
{
    public sealed record SearchVehiclesQuery(
    string PickupLocationId,
    string DropoffLocationId,
    DateTime PickupAt,
    DateTime DropoffAt);
}
