﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Vehicles.Search
{
    public sealed record VehicleSearchResult(
    Guid Id,
    string Plate,
    string VehicleTypeCode,
    string PickupLocationId);
}
