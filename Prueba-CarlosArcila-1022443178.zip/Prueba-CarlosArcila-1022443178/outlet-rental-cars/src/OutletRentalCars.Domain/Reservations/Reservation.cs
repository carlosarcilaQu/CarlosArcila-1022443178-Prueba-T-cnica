﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Reservations
{
    public sealed class Reservation
    {
        public Guid Id { get; init; }
        public Guid VehicleId { get; init; }
        public string PickupLocationId { get; init; } = string.Empty;
        public string DropoffLocationId { get; init; } = string.Empty;
        public DateTime PickupAt { get; init; }
        public DateTime DropoffAt { get; init; }
        public ReservationStatus Status { get; set; }
    }
}
