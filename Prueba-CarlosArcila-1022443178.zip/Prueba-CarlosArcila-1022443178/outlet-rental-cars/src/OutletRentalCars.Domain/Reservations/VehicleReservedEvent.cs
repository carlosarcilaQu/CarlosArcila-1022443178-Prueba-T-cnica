﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Reservations
{
    public sealed record VehicleReservedEvent(
    Guid ReservationId,
    Guid VehicleId,
    DateTime PickupAt,
    DateTime DropoffAt);
}
