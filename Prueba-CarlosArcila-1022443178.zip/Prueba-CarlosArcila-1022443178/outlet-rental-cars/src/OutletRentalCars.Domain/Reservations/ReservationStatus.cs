﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.Domain.Reservations
{
    public enum ReservationStatus
    {
        Active = 1,
        Cancelled = 2
    }
}
