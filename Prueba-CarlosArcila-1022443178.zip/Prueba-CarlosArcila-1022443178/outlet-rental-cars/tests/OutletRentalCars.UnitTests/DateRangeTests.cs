﻿using OutletRentalCars.Application.Common.Time;


namespace OutletRentalCars.UnitTests
{
    public sealed class DateRangeTests
    {
        [Theory]
        [InlineData("2026-02-10T10:00:00", "2026-02-12T10:00:00", "2026-02-09T10:00:00", "2026-02-10T10:00:00", false)] // Touch boundary
        [InlineData("2026-02-10T10:00:00", "2026-02-12T10:00:00", "2026-02-12T10:00:00", "2026-02-13T10:00:00", false)] // Touch boundary
        [InlineData("2026-02-10T10:00:00", "2026-02-12T10:00:00", "2026-02-11T10:00:00", "2026-02-13T10:00:00", true)]  // Overlap
        [InlineData("2026-02-10T10:00:00", "2026-02-12T10:00:00", "2026-02-09T10:00:00", "2026-02-11T10:00:00", true)]  // Overlap
        public void Overlaps_Works(string s1, string e1, string s2, string e2, bool expected)
        {
            var start1 = DateTime.Parse(s1);
            var end1 = DateTime.Parse(e1);
            var start2 = DateTime.Parse(s2);
            var end2 = DateTime.Parse(e2);

            var result = DateRange.Overlaps(start1, end1, start2, end2);

            Assert.Equal(expected, result);
        }
    }
}
