﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace OutletRentalCars.IntegrationTests
{
    public sealed class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureAppConfiguration((_, config) =>
            {
                var settings = new Dictionary<string, string?>
                {
                    ["ConnectionStrings:MySql"] = "Server=localhost;Port=3306;Database=outlet_rental;User=outlet;Password=outlet;TreatTinyAsBoolean=false;",
                    ["Mongo:ConnectionString"] = "mongodb://root:root@localhost:27017",
                    ["Mongo:Database"] = "outlet_catalog"
                };

                config.AddInMemoryCollection(settings);
            });
        }
    }
}
