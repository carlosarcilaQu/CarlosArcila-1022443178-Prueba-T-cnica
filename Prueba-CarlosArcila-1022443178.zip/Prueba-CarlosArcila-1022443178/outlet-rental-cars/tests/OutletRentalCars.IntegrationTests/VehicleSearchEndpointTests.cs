﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace OutletRentalCars.IntegrationTests
{
    public sealed class VehicleSearchEndpointTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly HttpClient _client;

        public VehicleSearchEndpointTests(CustomWebApplicationFactory factory)
        {
            _client = factory.CreateClient();
        }

        [Fact]
        public async Task Search_Returns200AndJson()
        {
            var url = "/api/vehicles/search" +
                      "?pickupLocationId=BOG_AIRPORT" +
                      "&dropoffLocationId=MDE_AIRPORT" +
                      "&pickupAt=2026-02-10T09:00:00" +
                      "&dropoffAt=2026-02-10T12:00:00";

            var response = await _client.GetAsync(url);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var body = await response.Content.ReadAsStringAsync();
            Assert.StartsWith("[", body.Trim());
        }
    }
}
