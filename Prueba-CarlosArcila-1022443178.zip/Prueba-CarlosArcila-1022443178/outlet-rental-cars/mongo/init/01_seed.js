db = db.getSiblingDB("outlet_catalog");

db.locations.insertMany([
  { _id: "BOG_AIRPORT", name: "Bogotá Airport", countryCode: "CO" },
  { _id: "MDE_AIRPORT", name: "Medellín Airport", countryCode: "CO" }
]);

db.vehicleTypes.insertMany([
  { _id: "ECON", name: "Economy" },
  { _id: "SUV", name: "SUV" }
]);

db.markets.insertMany([
  { _id: "CO", enabledVehicleTypeCodes: ["ECON", "SUV"] }
]);
