USE outlet_rental;

CREATE TABLE IF NOT EXISTS vehicles (
  id CHAR(36) NOT NULL,
  plate VARCHAR(16) NOT NULL,
  status VARCHAR(32) NOT NULL,
  pickup_location_id VARCHAR(64) NOT NULL,
  vehicle_type_code VARCHAR(32) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_vehicles_plate (plate),
  KEY ix_vehicles_pickup_location (pickup_location_id),
  KEY ix_vehicles_status (status),
  KEY ix_vehicles_type (vehicle_type_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reservations (
  id CHAR(36) NOT NULL,
  vehicle_id CHAR(36) NOT NULL,
  pickup_location_id VARCHAR(64) NOT NULL,
  dropoff_location_id VARCHAR(64) NOT NULL,
  pickup_at DATETIME(6) NOT NULL,
  dropoff_at DATETIME(6) NOT NULL,
  status VARCHAR(32) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_reservations_vehicle (vehicle_id),
  KEY ix_reservations_status (status),
  KEY ix_reservations_pickup_at (pickup_at),
  KEY ix_reservations_dropoff_at (dropoff_at),
  CONSTRAINT fk_reservations_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
