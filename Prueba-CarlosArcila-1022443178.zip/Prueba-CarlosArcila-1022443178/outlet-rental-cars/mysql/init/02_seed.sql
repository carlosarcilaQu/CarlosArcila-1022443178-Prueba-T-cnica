USE outlet_rental;

INSERT INTO vehicles (id, plate, status, pickup_location_id, vehicle_type_code)
VALUES
  ('11111111-1111-1111-1111-111111111111', 'AAA111', 'Available',   'BOG_AIRPORT', 'SUV'),
  ('22222222-2222-2222-2222-222222222222', 'BBB222', 'Available',   'BOG_AIRPORT', 'ECON'),
  ('33333333-3333-3333-3333-333333333333', 'CCC333', 'Maintenance', 'BOG_AIRPORT', 'SUV'),
  ('44444444-4444-4444-4444-444444444444', 'DDD444', 'Available',   'MDE_AIRPORT', 'ECON');

INSERT INTO reservations (id, vehicle_id, pickup_location_id, dropoff_location_id, pickup_at, dropoff_at, status)
VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '22222222-2222-2222-2222-222222222222', 'BOG_AIRPORT', 'BOG_AIRPORT',
   '2026-02-10 10:00:00.000000', '2026-02-12 10:00:00.000000', 'Active');
